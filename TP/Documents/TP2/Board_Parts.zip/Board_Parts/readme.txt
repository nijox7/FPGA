Les deux répertoires sont à copier ici:

C:\Xilinx\Vivado\2018.3\data\boards\board_parts