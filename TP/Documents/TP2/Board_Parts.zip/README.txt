Copier le répertoire Basys3 (ou ceux des cartes que vous utilisez) à cet endroit:
C:\Xilinx\Vivado\2018.3\data\boards\board_parts